
Firmata 334

This firmware can be used in conjunction with software on many different
platforms to make it easier to use the Arduino with that software.

You can find it in Arduino SVN:

http://svn.berlios.de/viewcvs//arduino/trunk/firmwares/Standard_Firmata/Standard_Firmata.pde

And you can find out all about Firmata here:

http://arduino.cc/playground/Interfacing/Firmata
